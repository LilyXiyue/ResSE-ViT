1、We use Jupter Notebook to train and validate our proposed ResSE-ViT model.
2、Remember that dataset2、dataset3、dataset4 are directly placed on desk.
3、Make sure that all necessary libraries are installed before running the program.
4、For some evaluation metrics, you may need to calculate them through other methods based on the confusion matrix.
5、To successfully upload our data to Github, we split the dataset2，dataset3, and dataset4. Therefore, after downloading the data, you need to allocate the files       to their corresponding folders properly.